# Alternative Logos

Icons created by [Freepik](http://www.freepik.com/) from 
[Flaticon](https://www.flaticon.com/de/)
