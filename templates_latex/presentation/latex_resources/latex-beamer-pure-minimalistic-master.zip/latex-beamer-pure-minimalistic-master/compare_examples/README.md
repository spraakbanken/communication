# Compare Examples

These examples require the pure-minimalistic theme to be
either moved next to the source files, or requires
the theme to be set over the `TEXINPUTS` path.
